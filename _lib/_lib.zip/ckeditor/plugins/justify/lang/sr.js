﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'sr', {
	block: 'Обострано равнање',
	center: 'Центриран текст',
	left: 'Лево равнање',
	right: 'Десно равнање'
} );
