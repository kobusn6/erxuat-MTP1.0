﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'justify', 'zh', {
	block: '左右對齊',
	center: '置中',
	left: '靠左對齊',
	right: '靠右對齊'
} );
