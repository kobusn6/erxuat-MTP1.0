<?php
	class captcha
	{
		var $link;
		function __construct()
		{
			
		}
		
		function CaptchaImage()
		{
			$img_path = '../_images/captcha/';
			$base = basename($_SERVER['PHP_SELF']);
			if ($base == 'index.php')
			{
				$img_path = '_images/captcha/';
			}
			
			//CREATE CAPTCHA IMAGE		
			//create random 5 character string (alphanumeric)
			$img_string = md5(uniqid(rand()));
			$img_string = substr($img_string,0,5);
			//$font_type = 5;
			$img_font_size = 5;
			$img_font = 'arial.ttf';
			
			$img_width = 120;
			$img_height = 30;
			// Create a blank image and add some text
			$im = imagecreatetruecolor($img_width, $img_height);	
		
			//Set some colors
			$white = imagecolorallocate($im, 255, 255, 255);
			$grey = imagecolorallocate($im, 128, 128, 128);
			$black = imagecolorallocate($im, 0, 0, 0);	
			$red = imagecolorallocate($im, 233, 14, 91);	
			
			$bg_color = $white;
			$text_color = $red;
			$line_color = $black;
			
			//Add the background color
			imagefilledrectangle($im, 0, 0, ($img_width - 1), ($img_height - 1), $bg_color);
				
			//Add the string
			imagestring($im, $img_font_size, ($img_width / 3), ($img_height / 3),  $img_string, $text_color);
			//imagettftext($im, $img_font_size, 0, ($img_width / 3), ($img_height / 3), $text_color, $img_font, $img_string);
			
			//Add the strikethrough line
			imageline( $im, 0, 0, $img_width, $img_height, $line_colour );
			
			// Save the image as 'simpletext.jpg'
			$captcha_image = $img_path.$img_string.'.jpg';
			imagejpeg($im, $captcha_image);
			
			// Free up memory
			imagedestroy($im);
			
			return $captcha_image;
		}
		
		
	}

?>