<?php
	class dbconnection
	{
		var $link;
		function __construct()
		{
			
		}
		
		function OpenDatabaseConnection3()
		{
			if (file_exists("_config/systemDBConf.php"))
			{
				require_once("_config/systemDBConf.php");
			}
			else
			{
				require_once("../_config/systemDBConf.php");
			}
			Global $link;
			$link = pg_connect("host=".$conf['sms_dbhost']." dbname=".$conf['sms_dbname']." user=".$conf['sms_dbuser']." password=".$conf['sms_dbpass']."");
			return $link;
		}		
		
		function OpenDatabaseConnection2()
		{
			if (file_exists("_config/systemDBConf.php"))
			{
				require_once("_config/systemDBConf.php");
			}
			else
			{
				require_once("../_config/systemDBConf.php");
			}
			Global $link;
			$link = pg_connect("host=".$conf['ast_dbhost']." dbname=".$conf['ast_dbname']." user=".$conf['ast_dbuser']." password=".$conf['ast_dbpass']."");
			return $link;
		}		
		
		function OpenDatabaseConnection()
		{
			if (file_exists("_config/systemDBConf.php"))
			{
				require_once("_config/systemDBConf.php");
			}
			else
			{
				require_once("../_config/systemDBConf.php");
			}
			Global $link;
			$link = pg_connect("host=".$conf['dbhost']." dbname=".$conf['dbname']." user=".$conf['dbuser']." password=".$conf['dbpass']."");
							//or die("Data connection unavailable at the moment, please check back later. ". pg_last_error($link));
			//return pg_last_error($dbconn);
			return $link;	
		}
	
		function CloseDatabaseConnection()
		{
			Global $link;
			pg_close($link); 
		}
		
		function OpenDatabaseConnectionMySQL()
		{
			if (file_exists("_config/systemDBConf.php"))
			{
				require("_config/systemDBConf.php");
			}
			else
			{
				require("../_config/systemDBConf.php");
			}

			Global $linkM;
			$linkM = mysqli_connect($conf['dbhost'], $conf['dbuser'], $conf['dbpass'])
			       or die("Site unavailable at the moment, please check back later");//die("System Configuration Error");// : " . mysql_error()); 
			   	mysqli_select_db($linkM, $conf['dbname']) or die("Database Selection Error");
			return $linkM;
		}		
	
		function CloseDatabaseConnectionM()
		{
			Global $linkM;
			mysql_close($linkM); 
		}
		
	}

?>