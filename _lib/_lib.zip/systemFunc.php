<?php
//************************************************************************************************
// ABOUT: This file is used to store non-altered php system functions
// BY:    William Kruger
// Date:  2011-01-02
//************************************************************************************************
//FUNCTION LIST
//fieldProcessForSql($process)																					-> Process fields for mysql db update/insert
//clean_sql($str)																												-> Removes all sql unfriendly characters
//clean_blob($str)																											-> Removes all sql unfriendly characters
//web_content($str)																											-> Formats submitted details for web display
//format_content($str)																									-> Formats submitted details for web display
//firstUpper($str)																											-> Converts a string to first character uppercase
//redirect($to)																													-> Redirects todifferent page
//runExternal($cmd,&$code) 																							-> Executes an external script
//DateDays($day,$readonly='')																						-> Builds a select box for days of the month
//DateMonth($month,$readonly='')																				-> Builds a select box for month of the year
//DateYear($year,$readonly='',$start,$end,$elementname)									-> Builds a select box for years
//split_date($str_date,$param)																					-> Splits up a date string and returns the value needed. //Y - YEAR, M - MONTH, D - DAY, h - HOURS, m - MINUTES, s - SECONDS
//dateDispLong($str_date,$param)																				-> Returns a date string with long month and day/year if specified and according to order specified
//getMonth($monthNo,$param)																							-> Returns a long month according to month number passed
//dayOfWeek($dateString)																								-> Returns the day of the week from date string
//get_date_str($epoch_date)																							-> Converts and returns string date in format("YYYY-MM-DD hh:mm:ss") from epoch date
//get_date_epoch1($str_date)																						-> Converts and returns epoch date from date string
//get_date_epoch2($str_date)																						-> Converts and returns epoch date from date string
//datediff($date2,$date1)																								-> Calculates the difference between two dates: $date1=epoch,$date2=string
//timeLess($dateTime,$seconds)																					-> Calculates and returns the time less specified amount of seconds from date string
//valid_email($email)																										-> Validates email addresses
//_browser($a_browser = false, $a_version = false, $name = false)				-> Checks what browser user is using
//get_page_title($request_uri)																					-> Gets the page title from requesting uri
//do_login($uname,$pass)																								-> Login process / validation: SQL TABLE DETAILS: tablename=web_admin_users,usernamefield=username,paswwordfield=password
//ConnectDatabase()																											-> Connects to mysql database
//CloseConnection()																											-> Disconnects from mysql database
//encrypt($str)																													-> Encrypts a given string							$encrypted = encrypt($q);
//decrypt($str)																													-> Decrypts a given encrypted string		$decrypted = decrypt($encrypted);
//validateNumber($string)																								-> Strips out all non numeric values from a given string
//************************************************************************************************

function fieldProcessForSql($process)
{
	$fieldProcess = '';
	foreach ($_POST as $field => $value)
	{
		$fieldPrefix = substr($field,0,strpos($field,'__'));
		
		$fieldName = substr($field,(strpos($field,'__')+2));
		if ($fieldPrefix!="code")
		{
			$value = clean_sql($value);
		}
		#$value = str_replace(',',';',$value);
		
		if ($process=="new")
		{
			if ($field=='ex__sheets')
			{
				$fields .= 'sheets,';
				if ($value=='custom')
				{
					$values .= '"'.$_POST['ex__custsheets'].'",';
				}
				else
				{
					$values .= '"'.$_POST['ex__sheets'].'",';
				}
			}
			
			if ($fieldPrefix!="ex")
			{
				$fields .= $fieldName.',';
				if ($fieldPrefix=="str")
				{					
					$value = str_replace(',','|',$value);
					$values .= '"'.$value.'",';
				}
				elseif ($fieldPrefix=="num")
				{
					if ($value=='')
					{
						$value = 0;
					}
					$values .= $value.',';
				}
				elseif ($fieldPrefix=="arr")
				{
					$value = implode(',',$value);
					$values .= '"'.$value.'",';
				}
				elseif ($fieldPrefix=="date")
				{
					$values .= 'now(),';
				}
				elseif ($fieldPrefix=="code")
				{
					$values .= '"'.$value.'",';
				}
			}
		}
		elseif ($process=="edit")
		{		
			if ($field=='ex__sheets')
			{
				$field='sheets';
				if ($value=='custom')
				{
					$value='"'.$_POST['ex__custsheets'].'",';
				}
				else
				{
					$value='"'.$_POST['ex__sheets'].'",';
				}
				$set .= $field.'="'.$value.'",';
			}
			if ($fieldPrefix!="ex")
			{
				if ($fieldPrefix=="str")
				{					
					$value = str_replace(',','|',$value);
					$set .= $fieldName.'="'.$value.'",';
				}
				elseif ($fieldPrefix=="num")
				{
					if ($value=='')
					{
						$value = 0;
					}
					$set .= $fieldName.'='.$value.',';
				}
				elseif ($fieldPrefix=="arr")
				{
					$value = implode(',',$value);
					$set .= $fieldName.'="'.$value.'",';
				}
				elseif ($fieldPrefix=="date")
				{
					$set .= $fieldName.'=now(),';
				}
				elseif ($fieldPrefix=="code")
				{
					$set .= $fieldName.'="'.$value.'",';
				}
			}
		}
		
	}
	
	//FILE TYPE INPUT
	if (isset($_FILES))
	{
		foreach ($_FILES as $field => $value)
		{
			$fieldName = substr($field,(strpos($field,'__')+2));
			$value = $_FILES[$field]['name'];
			if ($value!='')
			{
				if ($process=="new")
				{
					$fields .= $fieldName.',';
					$values .= '"'.$value.'",';
				}
				elseif ($process=="edit")
				{
					$set .= $fieldName.'="'.$value.'",';
				}
			}
		}
	}
	
	if ($process=="new")
	{
		$fields = substr($fields,0,-1);
		$values = substr($values,0,-1);
		$fields = '('.$fields.')';
		$values = '('.$values.')';
		$fieldProcess = $fields.' values '.$values;
	}
	elseif ($process=="edit")
	{		
		$set = substr($set,0,-1);
		$fieldProcess = $set;
	}
	return $fieldProcess;
	
}

function clean_sql($str)
{
	$newstr = $str;
	$newstr = str_replace("'","\'",$newstr);
	$newstr = str_replace("`", "",$newstr);
	$newstr = str_replace('"','\"',$newstr);
	$newstr = str_replace("�", "",$newstr);
	#$newstr = str_replace("?", "",$newstr);
	#$newstr = str_replace("&", "and",$newstr);
	$newstr = str_replace("$", " ",$newstr);
	$newstr = str_replace("^p", " ",$newstr);
	$newstr = str_replace("\r", " ",$newstr);
	$newstr = str_replace("\n", " ",$newstr);
	$newstr = str_replace("^", " ",$newstr);
	$newstr = str_replace("%", " ",$newstr);
	return $newstr;
}

function clean_blob($str)
{
	$newstr = $str;
	$newstr = str_replace("'","",$newstr);
	$newstr = str_replace("`", "",$newstr);
	$newstr = str_replace('"','',$newstr);
	$newstr = str_replace("�", "",$newstr);
	$newstr = str_replace("?", "",$newstr);
	#$newstr = str_replace("&", "and",$newstr);
	$newstr = str_replace("$", "",$newstr);
	$newstr = str_replace("^p", " ",$newstr);
	$newstr = str_replace("\r", " ",$newstr);
	$newstr = str_replace("\n", " ",$newstr);
	$newstr = str_replace("^", " ",$newstr);
	$newstr = str_replace("%", "",$newstr);
	$newstr = str_replace("/", "",$newstr);
	return $newstr;
}

function web_content($str)
{
	$newstr = $str;
	$newstr = str_replace("^p", "<br>",$newstr);
	$newstr = str_replace("\r", "<br>",$newstr);
	$newstr = str_replace("\n", "<br>",$newstr);
	$newstr = str_replace("<br><br>", "<br>",$newstr);
	$newstr = str_replace("/", "\/",$newstr);
	$newstr = str_replace('"','\"',$newstr);
	$newstr = str_replace("'","\'",$newstr);
	#$newstr = str_replace("\","\",$newstr);
	return $newstr;
}

function format_content($str)
{
	$newstr = $str;
	echo "<script>alert('".$newstr."');</script>";
	$new_str = str_replace('<br>',"\n",$newstr);
	echo "<script>alert('".$newstr."');</script>";
	return $newstr;
}

function firstUpper($str)
{
	$newstr = $str;
	$newstr = strtolower($newstr);
	$newstr = strtoupper(substr($newstr,0,1)).substr($newstr,1);
	return $newstr;
}

function redirect($to)
{
 header("location:$to");
}

function runExternal($cmd,&$code) 
{ 
    define('FD_SETSIZE', 256); 
    $descriptorspec = array( 
        0 => array("pipe", "r"),  // stdin is a pipe that the child will read from 
        1 => array("pipe", "w"),  // stdout is a pipe that the child will write to 
        2 => array("pipe", "w") // stderr is a file to write to 
    ); 
    $pipes= array(); 
    $process = proc_open($cmd, $descriptorspec, $pipes); 
    $output= ""; 
    if (!is_resource($process)) return false; 
    #close child's input imidiately 
    fclose($pipes[0]); 
    stream_set_blocking($pipes[1],false); 
    stream_set_blocking($pipes[2],false); 
    $todo= array($pipes[1],$pipes[2]); 
    while( true ) { 
             $read = array(); 
        if( !feof($pipes[1]) ) $read[] = $pipes[1]; 
        if( !feof($pipes[2]) ) $read[] = $pipes[2]; 
        if (!$read) break; 
        $ready = stream_select($read, $write=NULL, $ex=NULL, 2); 
        if ($ready === false) { 
                $output = "A Socket error has occured!"; 
          break; #should never happen - something died 
        } 
        
        foreach ($read as $r) { 
            $s= fread($r,1024); 
            $output.= $s; 
        } 
    } 
    fclose($pipes[1]); 
    fclose($pipes[2]); 
    $code= proc_close($process); 
    return $output; 
} 

function DateDays($day,$readonly='')
{
	if($readonly =='readonly'){
		$html = '<input type="text" maxlength="10" size="1" name="register[]" id="birth_day" value="'.$day.'" readonly>';
		return $html;
	}
	$html = '<select name="str_date[]" id="day" >';
	$html .='<option value="x" selected>Day</option>';
	for($i=1;$i<32;$i++){
		if(strlen($i)<2){
			$i = '0'.$i;
		}
		if($i == $day){
			$html .= '<option value="'.$i.'" selected>'.$i.'</option>';
		}else{
			$html .= '<option value="'.$i.'">'.$i.'</option>';
		}//end if
	}
	$html .= '</select>';
	return $html;
}

function DateMonth($month,$readonly='')
{
	if($readonly =='readonly'){
		$mon = array('01'=>'Jan','02'=>'Feb','03'=>'Mar','04'=>'Apr','05'=>'May','06'=>'Jun','07'=>'Jul','08'=>'Aug','09'=>'Sep','10'=>'Oct','11'=>'Nov','12'=>'Dec');
		$html = '<input type="text" maxlength="10" size="2" name="register[]" id="birth_month"  value="'.$mon[$month].'" readonly>';
		return $html;
	}
	$html = '<select name="str_date[]" id="month">';
	$html .='<option value="x" selected>Month</option>';
	if($month == '01'){
		$html .= '<option value="01" selected>Jan</option>';
	}else{
		$html .= '<option value="01">Jan</option>';
	}
	if($month == '02'){
		$html .= '<option value="02" selected>Feb</option>';
	}else{
		$html .= '<option value="02">Feb</option>';
	}
	
	if($month == '03'){
		$html .= '<option value="03" selected>Mar</option>';
	}else{
		$html .= '<option value="03">Mar</option>';
	}
	
	if($month == '04'){
		$html .= '<option value="04" selected >Apr</option>';
	}else{
		$html .= '<option value="04">Apr</option>';
	}
	
	if($month == '05'){
		$html .= '<option value="05" selected >May</option>';
	}else{
		$html .= '<option value="05">May</option>';
	}
	
	if($month == '06'){
		$html .= '<option value="06" selected >Jun</option>';
	}else{
		$html .= '<option value="06">Jun</option>';
	}
	
	if($month == '07'){
		$html .= '<option value="07" selected >Jul</option>';
	}else{
		$html .= '<option value="07">Jul</option>';
	}
	
	if($month == '08'){
		$html .= '<option value="08" selected >Aug</option>';
	}else{
		$html .= '<option value="08">Aug</option>';
	}
	
	if($month == '09'){
		$html .= '<option value="09" selected >Sep</option>';
	}else{
		$html .= '<option value="09">Sep</option>';
	}
	
	if($month == '10'){
		$html .= '<option value="10" selected >Oct</option>';
	}else{
		$html .= '<option value="10">Oct</option>';
	}
	
	if($month == '11'){
		$html .= '<option value="11" selected >Nov</option>';
	}else{
		$html .= '<option value="11">Nov</option>';
	}
	
	if($month == '12'){
		$html .= '<option value="12" selected >Dec</option>';
	}else{
		$html .= '<option value="12">Dec</option>';
	}
	
	$html .= '</select>';
	return $html;
}

function DateYear($year,$readonly='',$start,$end,$elementname)
{
	if($readonly == 'readonly'){
			for($i=$start;$i<$end;$i++){
				$x = $i;
			if($x == $year){
					$html = '<input type="text" maxlength="10" size="4" name="str__'.$elementname.'" id="'.$elementname.'"  value="'.$x.'" readonly>';
				}//end if
			}//end for
	}else{
		$html = '<select name="str__'.$elementname.'" id="'.$elementname.'">';
		//$html .='<option value="x" selected>Year</option>';
		for($i=$start;$i<$end;$i++){
			$x = $i;
			if($x == $year){
				$html .= '<option value="'.$x.'" selected>'.$x.'</option>';
			}
			else
			{
				$html .= '<option value="'.$x.'">'.$x.'</option>';
			}
		}
		$html .= '</select>';
	}
	return $html;
}

//**************************************************************************************
//FUNCTION : this function splits up a date string and returns the value needed.
//Y - YEAR, M - MONTH, D - DAY, h - HOURS, m - MINUTES, s - SECONDS
function split_date($str_date,$param)
{
	$Y = substr($str_date,0,4);
	$M = substr($str_date,5,2);
	$D = substr($str_date,8,2);
	$h = substr($str_date,11,2);
	$m = substr($str_date,14,2);
	$s = substr($str_date,17,2);
	
	//$result = '$'.$param;
	
	switch ($param) {
		case "Y":
			$result = $Y;
			break;
		case "M":
			$result = $M;
			break;
		case "D":
			$result = $D;
			break;
		case "h":
			$result = $h;
			break;
		case "m":
			$result = $m;
			break;
		case "s":
			$result = $s;
			break;
	}
	
	
	return $result;
}

//**************************************************************************************
//FUNCTION : 	this function returns a date string with long month and day/year if specified
//						and according to order specified
//						eg.('2010-04-02','D,M,Y') -> result: 2 April 2010
//						eg.('2010-04-02','D,M') -> result: 2 April
//						eg.('2010-04-02','M,D') -> result: April 2
//						eg.('2010-04-02','M,Y') -> result: April 2010
function dateDispLong($str_date,$param)
{
	$format = explode(",",$param);
	$D = split_date($str_date,"D");
	if ($D<10)
	{
		$D = str_replace("0","",$D);
	}
	$monthNo = split_date($str_date,"M");
	$M = getMonth($monthNo,"l");
	$Y = split_date($str_date,"Y");
	
	$returnDate = '';
	for($i=0;$i < sizeof($format);$i++)
	{
		if ($format[$i]=="D")
		{
			$returnDate .= $D." ";
		}
		elseif ($format[$i]=="M")
		{
			$returnDate .= $M." ";
		}
		elseif ($format[$i]=="Y")
		{
			$returnDate .= $Y." ";
		}
	}
	$returnDate = substr($returnDate,0,-1);	//removes space at end of string
	
	return $returnDate;

}


//**************************************************************************************
//FUNCTION : this function returns a long month according to month number passed
function getMonth($monthNo,$param)
{
		$param = strtolower($param);
		if ($param=="s")
		{
			$mon = array('01'=>'Jan','02'=>'Feb','03'=>'Mar','04'=>'Apr','05'=>'May','06'=>'Jun','07'=>'Jul','08'=>'Aug','09'=>'Sep','10'=>'Oct','11'=>'Nov','12'=>'Dec');
		}
		elseif ($param=="l")
		{
			$mon = array('01'=>'January','02'=>'February','03'=>'March','04'=>'April','05'=>'May','06'=>'June','07'=>'July','08'=>'August','09'=>'September','10'=>'October','11'=>'November','12'=>'December');
		}
		$Month = $mon[$monthNo];
	
		return $Month;
}	

//**************************************************************************************
//FUNCTION : this function returns the day of the week from date string
function dayOfWeek($dateString)
{
	$epoch_date = get_date_epoch1($dateString);
	$dayOfWeek = date("l",$epoch_date);
	
	return $dayOfWeek;
}

//**************************************************************************************
//FUNCTION : this function converts and returns string date in format("YYYY-MM-DD hh:mm:ss") from epoch date.
function get_date_str($epoch_date)
{
	$str_date = date("Y-m-d H:i:s",$epoch_date);
	
	return $str_date;
}

//**************************************************************************************
//FUNCTION : this function converts and returns epoch date from date string.
function get_date_epoch1($str_date)
{	
	$epoch_date = strtotime($str_date);		
	
	return $epoch_date;
}

//**************************************************************************************
//FUNCTION : this function converts and returns epoch date from date string.
function get_date_epoch2($str_date)
{
	$Y = substr($str_date,0,4);
	$m = substr($str_date,5,2);
	$d = substr($str_date,8,2);
	$h = substr($str_date,11,2);
	$min = substr($str_date,14,2);
	$s = substr($str_date,17,2);
	$epoch_date = mktime($h, $min, $s, $m, $d, $Y, -1);
	
	return $epoch_date;
}

//**************************************************************************************
//FUNCTION : this function calculates the difference between two dates
function datediff($date2,$date1)
{
	$Y = substr($date2,0,4);
	$m = substr($date2,5,2);
	$d = substr($date2,8,2);
	$h = substr($date2,11,2);
	$min = substr($date2,14,2);
	$s = substr($date2,17,2);
	$new_date2 = mktime($h, $min, $s, $m, $d, $Y, -1);
	//echo $new_date2."<br>";
	$diff = $date1 - $new_date2;
	//die($diff." = ".$date1." - ".$new_date2);
	$diff = floor((($diff/60)/60)/24);
	//$diff = floor((($diff/60)));
	
	//die($diff);
	
	return $diff;
}

//**************************************************************************************
//FUNCTION : this function calculates and returns the time less specified amount of seconds from date string
function timeLess($dateTime,$seconds)
{
	$epochDate = get_date_epoch1($dateTime);
	$newDate = $epochDate - $seconds;
	$newDateStr = get_date_str($newDate);
	
	
	$h = split_date($newDateStr,'h');
	$m = split_date($newDateStr,'m');
	$s = split_date($newDateStr,'s');
	
	$new_time = $h.':'.$m.':'.$s;
	
	return $new_time;
}

//**************************************************************************************
//FUNCTION : this function validates email addresses
function valid_email($email)
{
	$valid = "No";
	$pos1 = strpos($email,"@",0);
	if ($pos1 > 0){
		$pos2 = strpos($email,".",$pos1);
	}
	if ($pos1 >= $pos2){//invalid email address
		$valid = "No";
	}else{
		$valid = "Yes";
	}

	return $valid;
}

//**************************************************************************************
//FUNCTION : the below two functions are used to check what browser user is using
function w($a = '')
{
    if (empty($a)) return array();
   
    return explode(' ', $a);
}

function _browser($a_browser = false, $a_version = false, $name = false)
{
    $browser_list = 'msie firefox konqueror safari netscape navigator opera mosaic lynx amaya omniweb chrome avant camino flock seamonkey aol mozilla gecko';
    $user_browser = strtolower($_SERVER['HTTP_USER_AGENT']);
    $this_version = $this_browser = '';
   
    $browser_limit = strlen($user_browser);
    foreach (w($browser_list) as $row)
    {
        $row = ($a_browser !== false) ? $a_browser : $row;
        $n = stristr($user_browser, $row);
        if (!$n || !empty($this_browser)) continue;
       
        $this_browser = $row;
        $j = strpos($user_browser, $row) + strlen($row) + 1;
        for (; $j <= $browser_limit; $j++)
        {
            $s = trim(substr($user_browser, $j, 1));
            $this_version .= $s;
           
            if ($s === '') break;
        }
    }
   
    if ($a_browser !== false)
    {
        $ret = false;
        if (strtolower($a_browser) == $this_browser)
        {
            $ret = true;
           
            if ($a_version !== false && !empty($this_version))
            {
                $a_sign = explode(' ', $a_version);
                if (version_compare($this_version, $a_sign[1], $a_sign[0]) === false)
                {
                    $ret = false;
                }
            }
        }
       
        return $ret;
    }
   
    //
    $this_platform = '';
    if (strpos($user_browser, 'linux'))
    {
        $this_platform = 'linux';
    }
    elseif (strpos($user_browser, 'macintosh') || strpos($user_browser, 'mac platform x'))
    {
        $this_platform = 'mac';
    }
    else if (strpos($user_browser, 'windows') || strpos($user_browser, 'win32'))
    {
        $this_platform = 'windows';
    }
   
    if ($name !== false)
    {
        return $this_browser . ' ' . $this_version;
    }
   
    return array(
        "browser"      => $this_browser,
        "version"      => $this_version,
        "platform"     => $this_platform,
        "useragent"    => $user_browser
    );
}

//**************************************************************************
//FUNCTION: gets the page title from requesting uri
function get_page_title($request_uri)
{
	$request_uri = substr($request_uri,1);
	
	if (!strstr($request_uri,'/'))
	{
		$page_title = 'welcome';
	}
	else
	{
		$strpos = strpos($request_uri,'/');
		$page_title = substr($request_uri,0,$strpos);
	}
	return $page_title;	
}

//**************************************************************************
//FUNCTION: login process / validation
function do_login($uname,$pass)
{
//	include("connections.php");	
//	ConnectDatabase();
	$valid = 0;
	//die('*'.$uname.','.$pass.'*');
	if ($uname=="" || $pass=="")
	{
		//die('a');
		$valid = 2;
	}
	else
	{
		//die('b');
		$sql_lu1 = 'select * from web_admin_users where username="'.$uname.'" and password="'.$pass.'" ';
		$res_lu1 = mysql_query($sql_lu1);// or die("Your request could not be processed, please contact the system administrator");
		$row_lu1_numrows = mysql_num_rows($res_lu1);
		//die($sql_lu1);
		if ($row_lu1_numrows>0)
		{
			$valid = 1;			
			$row_lu1 = mysql_fetch_array($res_lu1);
			$_SESSION['ADMIN_USERNAME'] = $row_lu1['firstname'].' '.$row_lu1['lastname'];
			$_SESSION['ADMIN_LEVEL'] = $row_lu1['admin_level'];
		}
		else
		{
			$valid = 2;
		}
	}
	
	//die('*'.$valid.'*');
	return $valid;
}

//****************************************************************************
//FUNCTION: used to connec to the database
	function ConnectDatabase()
	{	
		if (file_exists("_inc/system/systemDBConf.php"))
		{
			include("_inc/system/systemDBConf.php");
		}
		else
		{
			include("../_inc/system/systemDBConf.php");
		}
		Global $link;
		$link = mysql_connect($conf['server'], $conf['username'], $conf['password'])
		       or die("Site unavailable at the moment, please check back later");//die("System Configuration Error");// : " . mysql_error()); 
		       
//		$link = mysql_connect($conf['server'], $conf['username'], $conf['password']); 
//		if (!$link) 
//		{
//    	die('Could not connect: ' . mysql_error()); 
//    } 
//    echo 'Connected successfully'; mysql_close($link);

		       
		   	mysql_select_db($conf['db']) or die("Database Selection Error");
		
	}//end function 

//**************************************************************************
//FUNCTION: used to close the connection
	function CloseConnection()
	{
		Global $link;
		mysql_close($link); 
	}//end function
	
	
//**************************************************************************
//FUNCTION: encrypts a given str
	function encrypt($str)
	{
		session_start();
	
		$encryptionkey = '';
		if (isset($_SESSION['ENCKEY']))
		{
			$encryptionkey = $_SESSION['ENCKEY'];
		}
		
		$cipher = $_SESSION['CIPHER'];
		$encmode = $_SESSION['ENCMODE'];
		
		$encryptStr = mcrypt_encrypt($cipher, $encryptionkey, $str, $encmode, $encryptionkey);
		$encoded = base64_encode($encryptStr);

		return $encoded; 
	}//end function encrypt()

//**************************************************************************
//FUNCTION: decrypts an encrypted string
	function decrypt($str)
	{
		session_start();
//		echo '<pre>';
//		print_r($_SESSION);
//		echo '</pre>';
		$encryptionkey = '';
		if (isset($_SESSION['ENCKEY']))
		{
			$encryptionkey = $_SESSION['ENCKEY'];
		}
		
		$cipher = $_SESSION['CIPHER'];
		$encmode = $_SESSION['ENCMODE'];

		$decodeData = base64_decode($str);
		$decoded = mcrypt_decrypt($cipher, $encryptionkey, $decodeData, $encmode, $encryptionkey);
		$decoded = rtrim($decoded, "\0");
		
		return $decoded;
	}//end function decrypt()


//**************************************************************************
//FUNCTION: strips out all non numeric values from a given string
	function validateNumber($string)
	{
		$newNo = '';
		$strArray = str_split($string , 1);
		$countStrArray = count($strArray);
		for ($index = 0; $index < $countStrArray; $index++)
		{
			if (is_numeric($strArray[$index]))
			{
				$newNo .= $strArray[$index];
			}
		}
		
		return $newNo;
	}

?>